"""Vendored polib."""
